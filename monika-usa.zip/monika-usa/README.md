# Monika USA‑sse

Monika USA‑sse on lihtne keeleõppe rakendus, mis aitab eesti keele rääkijal harjutada
levinumaid ingliskeelseid fraase enne reisi Ameerika Ühendriikidesse. Rakendus töötab
täielikult brauseris, seega ei nõua see installeerimist ega serveripoolset
tarkvara. PWA (progressive web app) funktsionaalsus lubab rakenduse lisada
nutitelefoni avakuvale ning kasutada ka ilma internetiühenduseta.

## Funktsioonid

* **Valdkonnad**: lennujaam, lennuk, passikontroll, hotell, transport,
  restoran, pood, tänav, hädaolukord, auto rent, sõit ja kütus, Los Angeles,
  Las Vegas, viisakus.
* **Kõnekartid**: iga kaart näitab esmalt eestikeelset fraasi; inglise tõlge
  avaneb nupule vajutades. Kasutaja saab märkida, kas ta mäletas fraasi õigesti
  või valesti. Õigete vastuste puhul pikeneb järgmise kordamise intervall,
  valede puhul lüheneb.
* **Kõnesüntees (TTS)**: ingliskeelne fraas loetakse ette (US hääldus).
* **Kõnetuvastus (ASR)**: kasutaja saab proovida fraasi ise välja öelda ja
  näha, mida brauser kuulis. Toetab `SpeechRecognition` API‑d brauserites,
  mis seda võimaldavad (Chrome).
* **Otsing ja filtrid**: fraase saab otsida ning filtreerida kategooria
  alusel. Oma fraaside lisamine on võimalik.
* **Andmete salvestus**: progress ja lisatud fraasid salvestatakse
  brauseri `localStorage`'i. Andmeid saab importida ja eksportida JSON
  failidena.

## Kasutamine

1. Ava rakenduse leht GitHub Pages’ist (kuva linki tuleb poole workflow abil genereerida).
2. Kasuta Chrome’is menüüd “Add to Home screen / Lisa avakuvale”, et lisada
   rakendus oma telefoni nagu tavapärane äpp.
3. Esmalt vali filtrist soovitud kategooria või kasuta otsingut.
4. Vajuta **“Näita tõlget”**, et näha ingliskeelset fraasi.
5. **“Kuula inglise keelt”** mängib teksti kõneks.
6. **“Ütle ise”** käivitab kõnetuvastuse.
7. **“Õige”** või **“Vale”** märgistavad korduse edukust.

## Arendamine

Projekt on täielikult staatiline ja ei vaja Node.js või teisi paketihalduse
tööriistu. Kui soovid muuta koodi, tee muudatused failides ja push’i need
GitHubi. GitHub Actions workflow ehitab ja avaldab saidi iga `main` haru push’i
järgselt GitHub Pages’ile.

## Autor

Käesolev projekt loodi automaatselt chatGPT abiga. Feel free to fork and
adapt.